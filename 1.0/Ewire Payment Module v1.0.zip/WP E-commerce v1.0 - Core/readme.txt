Ewire Payment Module
03-01-2010
For Wordpress e-Commerce

Release notes: ewirepayment.codeplex.com

** Version 1.0B **

This version is without complete,renew and cancel externally.
Therefore remember, when a Ewire order has been submitted it shall be
completed in your ewire account on ewire.dk.


Ewire can not be held responsible for any damages or errors caused by the package,
problem resolving goto: ewirepayment.codeplex.com.

- Prestashop how-to install

	1. Open the folder "Wordpress" folder.
	2. Copy the folder "wp-content" into the folder:
	3. Goto your Wordpress - WP E Commerce backend and find Ewire under "Payment Options"
	4. Mark it and "Update"
	5. Choose Ewire from the list at the right and configure it
	   with the information found at your Ewire account under "Business".

Always make a test payment to assure that it functions as it shall.

Good luck,

Ewire

